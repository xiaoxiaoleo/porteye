Screenshots
===========

Worker dashboard:

.. image:: screenshots/dashboard.png
   :width: 100%

Task dashboard:

.. image:: screenshots/tasks.png
   :width: 100%

Worker tasks:

.. image:: screenshots/worker-tasks.png
   :width: 100%

Graphs:

.. image:: screenshots/monitor.png
   :width: 100%

Worker info:

.. image:: screenshots/pool.png
   :width: 100%

.. image:: screenshots/broker.png
   :width: 100%

.. image:: screenshots/limits.png
   :width: 100%

.. image:: screenshots/queues.png
   :width: 100%

Task info:

.. image:: screenshots/task.png
   :width: 100%

Configuration viewer:

.. image:: screenshots/config.png
   :width: 100%

